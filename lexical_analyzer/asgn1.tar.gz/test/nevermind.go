#Things to be done
    1) add a token naming illegal character!
    2) Proper formatting of output.
    3)
222
Hi+90
..
---
S="H"
A="dfffdd"
/* kyghjb
fhkdfjkdjflj
/* heloo
jfdjslfj
jh*/
/*
ji
*
/
jo
*/
<=
/**\
bdsh
***/
>>=
memsahab
x=-30
45-30
56.7
8+i8
int 20
-90.7
a *int
b **int
c * * * int
INTERFACE
interface
'heoll'
float b
return
var a=100
if temp==2:
   print "What \" 'the' \fuck?" + f + "the int of" + "kantq is awe
    +
    some" + g
    else:
    print "no fucking ida?"
    
45646.56
}
{
>>=
+=
-=
}
* float
:=
: =
<<
>>
...
